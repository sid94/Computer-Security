# Computer-Security

Siddhesh Vilas Kolhapure
B00815336
skolhap1@binghamton.edu

--------------------------------------------------------------------

Programming Langauge used : python  
code written in python version 3.7.3

---------------------------------------------------------------------

Whether your code was tested on bingsuns or remote.cs.
Yes, code was tested on remote.cs having python version 2.7.16

---------------------------------------------------------------------

How to compile and execute your program.
check python version :- python --version

if python version less than 3

python3 genpass.py
python3 verifypass.py 

if python version 3 or greater

python genpass.py
python verifypass.py 

---------------------------------------------------------------------

Anything special about submission

Genpass program will continuously be running in a loop asking the user to add more and more id and passwords.

verify pass will verify the id and password with the data stored in the password file and give out the result. Once the result is displayed the program will exit. 

