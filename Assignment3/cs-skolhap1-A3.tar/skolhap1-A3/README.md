# Computer-Security

Siddhesh Vilas Kolhapure
B00815336
skolhap1@binghamton.edu

--------------------------------------------------------------------

Programming Langauge used : python  
code written in python version 3.7.3

---------------------------------------------------------------------

Whether your code was tested on bingsuns or remote.cs.
Yes, code was tested on remote.cs having python version 2.7.16

---------------------------------------------------------------------

How to compile and execute your program.
check python version :- python --version

if python version less than 3

python3 server.py
python3 client.py remote.cs.binghamton.edu

if python version 3 or greater

python server.py
python client.py remote.cs.binghamton.edu

---------------------------------------------------------------------


 Certificate genration provide in gencert.txt file

 flow 

 1. run the server first
 2. then client
 3. enter id and password asked in client terminal
 4. server will receive the entered credentials and respond with the verification of those credentials
 5. client will receive the message
 6. client and server terminates 



