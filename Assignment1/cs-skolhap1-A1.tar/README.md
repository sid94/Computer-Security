# Computer-Security

Siddhesh Vilas Kolhapure
B00815336
skolhap1@binghamton.edu

--------------------------------------------------------------------

Programming Langauge used : python  
code written in python version 3.7.3

---------------------------------------------------------------------

Whether your code was tested on bingsuns or remote.cs.
Yes, code was tested on remote.cs having python version 2.7.16

---------------------------------------------------------------------

How to compile and execute your program.
check python version :- python --version

if python version less than 3

python3 mono.py in out 1 - encryption
python3 mono.py out in1 0 - decryption

if python version 3 or greater

python mono.py in out 1 - encryption
python mono.py out in1 0 - decryption

---------------------------------------------------------------------

Anything special about the code

1. During encryption file in and out should exist 

2. During decryption file out and in1 should exist
 



